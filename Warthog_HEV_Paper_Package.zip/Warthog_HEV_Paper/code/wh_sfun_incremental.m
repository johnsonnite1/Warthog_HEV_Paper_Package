function wh_sfun_incremental(b)
b.NumDialogPrms=2;b.DialogPrmsTunable={'Nontunable','Nontunable'};
p=b.DialogPrm(1).Data;b.NumInputPorts=1;b.NumOutputPorts=1;
b.SetPreCompInpPortInfoToDynamic;b.SetPreCompOutPortInfoToDynamic;
b.InputPort(1).Dimensions=5;b.InputPort(1).DirectFeedthrough=true;
b.InputPort(1).DatatypeID=0;b.InputPort(1).Complexity='Real';
b.OutputPort(1).Dimensions=10;b.OutputPort(1).DatatypeID=0;
b.OutputPort(1).Complexity='Real';b.SampleTimes=[p.Ts 0];
b.SimStateCompliance='DefaultSimState';
b.RegBlockMethod('PostPropagationSetup',@setup);
b.RegBlockMethod('InitializeConditions',@init);
b.RegBlockMethod('Outputs',@outputs);b.RegBlockMethod('Update',@update);
end
function setup(b)
p=b.DialogPrm(1).Data;b.NumDworks=1;b.Dwork(1).Name='ControllerState';
b.Dwork(1).Dimensions=size(p.A,1)+14;b.Dwork(1).DatatypeID=0;
b.Dwork(1).Complexity='Real';b.Dwork(1).UsedAsDiscState=true;
end
function init(b)
p=b.DialogPrm(1).Data;n=size(p.A,1);s=zeros(n+14,1);
s(n+4)=p.a0;s(n+5)=p.b0;b.Dwork(1).Data=s;
end
function outputs(b)
[o,~]=wh_kernel_incremental(b.InputPort(1).Data,b.Dwork(1).Data,b.DialogPrm(1).Data,b.DialogPrm(2).Data);
b.OutputPort(1).Data=o;
end
function update(b)
[~,s]=wh_kernel_incremental(b.InputPort(1).Data,b.Dwork(1).Data,b.DialogPrm(1).Data,b.DialogPrm(2).Data);
b.Dwork(1).Data=s;
end
