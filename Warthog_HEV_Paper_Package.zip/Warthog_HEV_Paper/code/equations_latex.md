$$
m\frac{dv}{dt}=F_{\mathrm{drive}}-F_{\mathrm{brake}}-F_{\mathrm{road}}(v)-mg\sin\theta
$$

$$
\begin{aligned}y_k^f&=y_{k-1}^f+\beta_y(y_k-y_{k-1}^f),\\e_k&=r_k-y_k^f,\qquad \beta_y=\frac{T_s}{\tau_y+T_s}\end{aligned}
$$

$$
\begin{aligned}\min_K\left\|\begin{bmatrix}W_e S\\W_u KS\\W_t T\end{bmatrix}\right\|_\infty,\qquad S&=(1+GK)^{-1},\\T&=GK(1+GK)^{-1}\end{aligned}
$$

$$
\begin{aligned}x^H_{k+1}&=A_Hx^H_k+B_He_k,\\h_k&=C_Hx^H_k+D_He_k,\qquad\Delta h_k=h_k-h_{k-1}\end{aligned}
$$

$$
\begin{aligned}\Delta y_k&\approx a_{k-1}\Delta y_{k-1}+b_{k-1}\Delta u_k+d_{k-1},\\\varepsilon_k&=\Delta y_k-a_{k-1}\Delta y_{k-1}-b_{k-1}\Delta u_k-d_{k-1}\end{aligned}
$$

$$
\begin{bmatrix}a_k^+\\b_k^+\end{bmatrix}=\Pi_\Omega\left\{\begin{bmatrix}a_{k-1}\\b_{k-1}\end{bmatrix}+\frac{\eta\varphi_k\varepsilon_k}{\mu+\varphi_k^T\varphi_k}\right\}
$$

$$
d_k^+=\operatorname{clip}(d_{k-1}+k_d\varepsilon_k,-d_{\max},d_{\max})
$$

$$
\Delta m_k=\operatorname{clip}\left(\frac{\rho b_k^+[\Delta r_k+\kappa e_k-a_k^+\Delta y_k-d_k^+]}{\lambda+(b_k^+)^2},-\delta_{\max},\delta_{\max}\right)
$$

$$
\begin{aligned}z_k&=z_{k-1}+\beta_c[(\Delta u_k)^2-z_{k-1}],\\c_k&=(1-b_k^{\mathrm{br}})\min\left(1,\sqrt{\frac{z_k}{z_{\min}}}\right)\exp\left[-\left(\frac{\varepsilon_k}{\varepsilon_{\max}}\right)^2\right]\end{aligned}
$$

$$
\begin{aligned}e_k^s&=e_{k-1}^s+\beta_e(e_k-e_{k-1}^s),\\\alpha_k^*&=c_k\alpha_{\max}\frac{(e_k^s)^2}{(e_k^s)^2+e_b^2}\end{aligned}
$$

$$
\begin{aligned}\alpha_k&=\operatorname{clip}\{\alpha_{k-1}+\beta_\alpha(\alpha_k^*-\alpha_{k-1}),0,\alpha_{\max}\},\\\beta_\alpha&=\frac{T_s}{\tau_\alpha+T_s}\end{aligned}
$$

$$
u_k^{\mathrm{raw}}=u_{k-1}^a+(1-\alpha_k)\Delta h_k+\alpha_k\Delta m_k
$$

$$
u_k^c=\operatorname{clip}\{\operatorname{clip}(u_k^{\mathrm{raw}},\ell_{k-1}-R,\ell_{k-1}+R),-1,1\}
$$

$$
\begin{gathered}q_k-q_{k-1}={}(1-\alpha_k)\Delta h_k+\alpha_k\Delta m_k^{\mathrm{abs}}\\+(\alpha_k-\alpha_{k-1})(m_{k-1}-h_{k-1})\end{gathered}
$$

$$
\begin{gathered}J={}\frac{E}{\min(E_{\mathrm{PI}},E_{\mathrm{MFAC}})}+\frac{0.15A}{\min(A_{\mathrm{PI}},A_{\mathrm{MFAC}})}\\+0.10\frac{V}{V_{\mathrm{PI}}}+2\left[\max\left(0,\frac{V}{V_{\mathrm{PI}}}-1.25\right)\right]^2\end{gathered}
$$

$$
\begin{aligned}\mathrm{RMSE}&=\sqrt{\frac{1}{T}\int_0^T E_v^2(t)\,dt},\qquad\mathrm{IAE}=\int_0^T|E_v(t)|\,dt,\\\mathrm{TV}_\tau&=\sum_k|\tau_k^a-\tau_{k-1}^a|\end{aligned}
$$

$$
D_H=11.1155483515
$$
