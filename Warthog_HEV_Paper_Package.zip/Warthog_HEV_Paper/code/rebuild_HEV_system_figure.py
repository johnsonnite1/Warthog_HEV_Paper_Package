from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
out=Path(__file__).resolve().parents[1]/'figures'
fig,ax=plt.subplots(figsize=(10.5,4.6));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
def box(x,y,w,h,t):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.008',facecolor='#f4f7fa',edgecolor='#2a394a',lw=1.2));ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=11,fontfamily='DejaVu Serif')
def line(pts,color='#1460a6',both=False):
 for a,b in zip(pts[:-2],pts[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],color=color,lw=1.7)
 ax.add_patch(FancyArrowPatch(pts[-2],pts[-1],arrowstyle='<->' if both and len(pts)==2 else '-|>',color=color,lw=1.7,mutation_scale=13))
 if both and len(pts)>2:ax.add_patch(FancyArrowPatch(pts[1],pts[0],arrowstyle='-|>',color=color,lw=1.7,mutation_scale=13))
box(.02,.66,.16,.17,'Engine');box(.29,.66,.20,.17,'Planetary\npower split');box(.61,.66,.17,.17,'Final drive\nand axle');box(.84,.66,.14,.17,'Wheels and\nvehicle');box(.29,.35,.20,.16,'MG1');box(.61,.35,.17,.16,'MG2');box(.02,.07,.16,.16,'HV battery');box(.29,.07,.49,.16,'DC link and power electronics')
line([(.18,.745),(.29,.745)]);line([(.49,.745),(.61,.745)]);line([(.78,.745),(.84,.745)]);line([(.39,.66),(.39,.51)],both=True);line([(.695,.51),(.695,.66)],both=True)
for x in [.39,.695]:line([(x,.23),(x,.35)],color='#26845b',both=True)
line([(.18,.15),(.29,.15)],color='#26845b',both=True)
ax.text(.52,.93,'Power split hybrid electric vehicle',ha='center',fontsize=14,fontweight='bold',fontfamily='DejaVu Serif')
ax.plot([.05,.12],[.94,.94],color='#1460a6',lw=2);ax.text(.13,.94,'Mechanical',va='center',fontsize=9);ax.plot([.05,.12],[.88,.88],color='#26845b',lw=2);ax.text(.13,.88,'Electrical',va='center',fontsize=9)
fig.savefig(out/'Fig01a_HEV_system.png',dpi=330,bbox_inches='tight');fig.savefig(out/'Fig01a_HEV_system.pdf',bbox_inches='tight')
