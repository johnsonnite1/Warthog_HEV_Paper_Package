function m=wh_metrics(T,c,sc)
t=T.time_s;e=T.reference_mps-T.speed_mps;duration=t(end)-t(1);u=T.applied_torque_Nm;
m.RMSE_mps=sqrt(trapz(t,e.^2)/duration);m.IAE_m=trapz(t,abs(e));
m.ITAE_ms=trapz(t,(t-t(1)).*abs(e));m.MaxError_mps=max(abs(e));
m.TorqueTV_Nm=sum(abs(diff(u)));m.TorqueRMS_Nm=sqrt(trapz(t,u.^2)/duration);
m.CommandViolationSamples=sum(abs(u)>c.torqueMax+1e-6);
m.BrakeFraction=trapz(t,double(T.mechanical_brake>.5))/duration;
% Differentiation uses the same approximately 0.1-second filter for all methods.
window=max(3,2*floor(.1/c.Ts/2)+1);vs=movmean(T.speed_mps,window);
a=gradient(vs,c.Ts);jerk=gradient(a,c.Ts);
m.JerkRMS_mps3=sqrt(trapz(t,jerk.^2)/duration);
m.RecoveryAfterGradeOn_s=NaN;
if sc.gradePercent~=0
 start=find(t>=sc.gradeOn,1);dwell=max(1,ceil(2/c.Ts));
 for k=start:numel(t)-dwell
  if all(abs(e(k:k+dwell))<=.2),m.RecoveryAfterGradeOn_s=t(k)-sc.gradeOn;break;end
 end
end
m.SOCinitial_pct=T.SOC_pct(1);m.SOCfinal_pct=T.SOC_pct(end);
valid=T.SOC_pct(isfinite(T.SOC_pct));if isempty(valid),m.SOCminimum_pct=NaN;else,m.SOCminimum_pct=min(valid);end
valid=T.MG2_power_kW(isfinite(T.MG2_power_kW));
if isempty(valid),m.MaxAbsMG2Power_kW=NaN;else,m.MaxAbsMG2Power_kW=max(abs(valid));end
end
