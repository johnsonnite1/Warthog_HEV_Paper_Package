function export_final_simulink_diagrams(studyFolder)
% Export the final saved wrapper/model without running or tuning a simulation.
% Run from the existing MATLAB experiment package, not this document folder.
if nargin==0,studyFolder=fullfile(pwd,'runs','ONE_RUN_20261102_172501_986');end
z=load(fullfile(studyFolder,'session.mat'),'c');c=z.c;
z=load(fullfile(studyFolder,'paths.mat'));names=fieldnames(z);paths=[];
for k=1:numel(names)
 v=z.(names{k});if isstruct(v)&&isfield(v,'speed')&&isfield(v,'mg'),paths=v;break;end
end
assert(~isempty(paths),'Could not locate saved instrumentation paths.');
z=load(fullfile(studyFolder,'selected_controller.mat'),'pSelected');p=z.pSelected;
frozen=fullfile(studyFolder,'frozen_code');addpath(frozen,'-begin');
addpath(genpath(c.vendorRoot),'-begin');
modelFile=fullfile(c.vendorRoot,'HEV',[c.model '.mdl']);
for name={c.model,c.mgModel}
 if bdIsLoaded(name{1})
  actual=lower(strrep(get_param(name{1},'FileName'),'\','/'));
  expected=lower(strrep(studyFolder,'\','/'));
  assert(startsWith(actual,[expected '/']),'A different model is loaded. Save and close it before exporting.');
 end
end
assignin('base','WHCFG',c);assignin('base','WHP',wh_core_params(p));assignin('base','WHMode',4);
load_system(modelFile);load_system(c.mgModel);
assert(strcmp(get_param(c.model,'SimulationStatus'),'stopped'),'Stop the simulation first.');
set_param([paths.speed '/Warthog Hinf MFAC'],'FunctionName','wh_sfun_incremental','Parameters','WHP, 4');
set_param([paths.speed '/Controller mode'],'Value','4');
wh_export_models(c,paths,'final_Warthog');
fprintf('Exported final Simulink diagrams. No simulation or tuning was run.\n%s\n',fullfile(studyFolder,'figures'));
end
