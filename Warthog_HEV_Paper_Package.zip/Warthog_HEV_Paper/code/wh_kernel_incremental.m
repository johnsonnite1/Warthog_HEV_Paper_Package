function [o,ns]=wh_kernel_incremental(z,s,p,mode)
% z=[reference m/s; true speed m/s; previous FINAL command Nm; brake; noise m/s]
% Experimental actuator-referenced INCREMENT blend; prior kernels unchanged.
% Partial-form increment predictor: dy_next = a*dy + b*du + bias.
% Positive b is a regime-specific design assumption, checked during synthesis.
n=size(p.A,1);assert(numel(s)==n+14 && numel(z)==5);
x=s(1:n);q0=s(n+1:end);
yp=q0(1);dyp=q0(2);upp=q0(3);a=q0(4);b=q0(5);bias=q0(6);
alpha=q0(7);ef=q0(8);exc=q0(9);last=q0(10);ui=q0(11);yf=q0(12);
reference=z(1)/p.vScale;previousReference=q0(13);
referenceIncrement=p.mfReferenceIncrement*(reference-previousReference);
measured=(z(2)+z(5))/p.vScale;
yf=yf+p.Ts/(p.noiseFilterTau+p.Ts)*(measured-yf);
e=z(1)/p.vScale-yf;up=z(3)/p.uScale;dy=yf-yp;du=up-upp;
innovation=dy-a*dyp-b*du-bias;
exc=exc+p.Ts/(p.confidenceTau+p.Ts)*(du^2-exc);
enabled=z(4)<.5;
valid=enabled && abs(du)>p.duMin && abs(innovation)<p.residualMax;
if valid
 reg=[dyp;du];candidate=[a;b]+p.eta*reg*innovation/(p.mu+reg'*reg);
 if all(isfinite(candidate)) && candidate(2)>0
  a=min(p.aMax,max(-p.aMax,candidate(1)));b=min(p.bMax,max(p.bMin,candidate(2)));
 else,valid=false;
 end
end
% A bounded disturbance increment estimate; held during brake override.
if enabled && isfinite(innovation)
 bias=min(p.biasMax,max(-p.biasMax,bias+p.disturbanceGain*innovation));
end
confidence=double(enabled)*min(1,sqrt(max(0,exc)/p.excitationMin))*exp(-(innovation/p.residualMax)^2);
if ~valid && abs(innovation)>=p.residualMax,confidence=0;end
ef=ef+p.Ts/(p.errorTau+p.Ts)*(e-ef);
target=confidence*p.alphaMax*ef^2/(ef^2+p.errorBand^2);
alpha=alpha+p.Ts/(p.blendTau+p.Ts)*(target-alpha);
alpha=min(p.alphaMax,max(0,alpha));
uH=p.C*x+p.D*e;
dm=p.rho*b/(p.lambda+b*b)*(referenceIncrement+p.mfTrackingFraction*e-a*dy-bias);
increment=min(p.deltaMax,max(-p.deltaMax,dm));
% Both proposed increments are referenced to the same previous applied
% actuator command. q0(14) stores previous Hinf candidate, not a private
% MFAC integrator. No delta-alpha * absolute-branch-gap term is introduced.
uM=up+increment;
deltaH=uH-q0(14);
uPI=p.Kp*e+ui;
switch mode
 case 0,raw=0; % external switch executes original vendor PI
 case 1,raw=uPI;
 case 2,raw=uH;
 case 3,raw=uM;
 case 4,raw=up+(1-alpha)*deltaH+alpha*increment;
 case 5,raw=up+(1-p.alphaFixed)*deltaH+p.alphaFixed*increment;
 otherwise,error('Invalid controller mode');
end
rate=p.rateNmPerSec*p.Ts/p.uScale;
u=min(1,max(-1,min(last+rate,max(last-rate,raw))));
% Existing vendor supervisor determines the actual next applied command.
xn=p.A*x+p.B*e;
if p.hinfAw>0 && norm(p.C)>1e-12
 mismatch=min(.1,max(-.1,up-last));
 xn=xn+p.hinfAw*p.C'/(p.C*p.C'+1e-9)*mismatch;
end
if mode==1,ui=ui+p.Ts*(p.Ki*e+p.piAw*(up-last));end
ui=min(1,max(-1,ui));
ns=[xn;yf;dy;up;a;b;bias;alpha;ef;exc;u;ui;yf;reference;uH];
effectiveAlpha=alpha;
if mode==5,effectiveAlpha=p.alphaFixed;end
o=[u*p.uScale;effectiveAlpha;a;b;bias;innovation;confidence;uH*p.uScale;uM*p.uScale;raw*p.uScale];
assert(all(isfinite(ns)) && all(isfinite(o)),'Nonfinite Warthog state');
end
