from pathlib import Path
import json,shutil
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Polygon
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT; OUT=ROOT; FIG=OUT/'figures'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.bbox':'tight','pdf.fonttype':42})
names=['PI','Hinf','MFAC','Warthog']; labels=['PI',r'$H_\infty$','MFAC','Warthog']; colors=['#222222','#c54c34','#26845b','#125da6']; styles=['-','--','-.','-']
scenarios=['fresh_payload_grade','fresh_noise_lag_seed8041','fresh_noise_lag_seed8042']; tags=['Payload and grade','Noise seed 8041','Noise seed 8042']
M=pd.read_csv(SRC/'final_metrics.csv'); M=M[M.controller.isin(names)&M.scenario.isin(scenarios)].copy();assert len(M)==12
T={}
for s in scenarios:
 for name in names:
  r=M[(M.scenario==s)&(M.controller==name)].iloc[0];d=pd.read_csv(SRC/'data'/f'{r.tag}.csv');T[s,name]=d
  e=d.reference_mps-d.speed_mps;t=d.time_s
  assert len(d)==7501 and abs(t.iloc[-1]-150)<1e-8
  assert abs(np.sqrt(np.trapezoid(e**2,t)/150)-r.RMSE_mps)<1e-10
M.to_csv(OUT/'tables/physical_results.csv',index=False)
N=M[M.scenario.str.contains('noise')].groupby('controller')[['RMSE_mps','IAE_m','MaxError_mps','TorqueTV_Nm','JerkRMS_mps3']].agg(['mean','std']);N.to_csv(OUT/'tables/noise_two_seed_summary.csv')
P=loadmat(SRC/'controller_design_tuned.mat',simplify_cells=True)['p'];
params={k:float(v) for k,v in P.items() if isinstance(v,(int,float))};params.update({k:np.asarray(P[k]).tolist() for k in ['A','B','C','D']});(OUT/'code/selected_numeric_parameters.json').write_text(json.dumps(params,indent=2))
shutil.copy(SRC/'physical_tuning.csv',OUT/'tables/physical_tuning.csv');shutil.copy(SRC/'controller_parameters.csv',OUT/'tables/controller_parameters.csv')
def save(fig,name):
 fig.savefig(FIG/(name+'.png'),dpi=330);fig.savefig(FIG/(name+'.pdf'));plt.close(fig)
def box(ax,x,y,w,h,text,fill='#f5f7fa',size=10):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.006,rounding_size=.008',facecolor=fill,edgecolor='#263746',lw=1));ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size)
def arr(ax,p,q,via=None,label=None):
 if via:
  pts=[p]+via+[q]
  for a,b in zip(pts[:-2],pts[1:-1]):ax.plot([a[0],b[0]],[a[1],b[1]],color='#263746',lw=1)
  p=pts[-2]
 ax.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=11,color='#263746',lw=1))
 if label:ax.text((p[0]+q[0])/2,(p[1]+q[1])/2+.02,label,ha='center',fontsize=8)
fig,ax=plt.subplots(figsize=(10.5,5));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
box(ax,.01,.65,.14,.13,'Reference and\nmeasured speed');box(ax,.21,.65,.15,.13,'Normalize and\nfilter speed');box(ax,.43,.80,.18,.12,'H∞ command\nincrement Δh');box(ax,.43,.52,.18,.12,'Projected estimator\nand MFAC Δm');box(ax,.67,.65,.14,.14,'Confidence gate\nand increment\nblend',fill='#eaf1fa');box(ax,.84,.65,.15,.14,'Torque limits\nand supervisor');box(ax,.84,.28,.15,.14,'Simscape\npower split HEV');box(ax,.43,.20,.19,.12,'Previous applied\ntorque feedback')
arr(ax,(.15,.715),(.21,.715));arr(ax,(.36,.715),(.43,.86),via=[(.395,.715),(.395,.86)]);arr(ax,(.395,.715),(.43,.58),via=[(.395,.58)]);arr(ax,(.61,.86),(.67,.75),via=[(.64,.86),(.64,.75)]);arr(ax,(.61,.58),(.67,.69),via=[(.64,.58),(.64,.69)]);arr(ax,(.81,.72),(.84,.72));arr(ax,(.915,.65),(.915,.42));arr(ax,(.86,.65),(.62,.26),via=[(.82,.60),(.82,.26)]);arr(ax,(.43,.26),(.43,.53),via=[(.39,.26),(.39,.53)]);arr(ax,(.39,.39),(.67,.66),via=[(.65,.39),(.65,.66)]);arr(ax,(.84,.34),(.08,.65),via=[(.08,.34)]);ax.text(.23,.36,'Measured speed',fontsize=9);ax.text(.53,.04,'Applied torque is sampled after the existing supervisory logic.\nThe H∞ and MFAC proposals share this actuator reference.',ha='center',fontsize=10);save(fig,'Fig02_closed_loop')
fig,ax=plt.subplots(figsize=(8.8,6.5));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
steps=[(.04,.83,.39,.11,'Acquire speed and reference;\napplied torque and brake flag'),(.04,.66,.39,.11,'Normalize, filter and form\nΔy, Δu and prediction residual'),(.04,.49,.39,.11,'Check brake, excitation and residual;\nproject accepted parameter updates'),(.56,.49,.40,.11,'Compute H∞ increment and\nregularized MFAC increment'),(.56,.66,.40,.11,'Update confidence and\nfiltered blending weight'),(.56,.83,.40,.11,'Blend from previous applied torque;\napply amplitude and rate limits'),(.56,.22,.40,.11,'Existing supervisor applies torque;\nlog diagnostics and update memories')]
for x,y,w,h,txt in steps:box(ax,x,y,w,h,txt,size=10)
arr(ax,(.235,.83),(.235,.77));arr(ax,(.235,.66),(.235,.60));arr(ax,(.43,.545),(.56,.545));arr(ax,(.76,.60),(.76,.66));arr(ax,(.76,.77),(.76,.83));arr(ax,(.96,.88),(.96,.275),via=[(.99,.88),(.99,.275)]);arr(ax,(.56,.275),(.04,.885),via=[(.015,.275),(.015,.885)]);ax.text(.5,.075,'Online loop repeats every 0.02 s. Parameter search is performed offline.',ha='center');save(fig,'Fig03_algorithm_flow')
fig,axes=plt.subplots(2,2,figsize=(9.5,5),sharex=True)
for j,s in enumerate(scenarios[:2]):
 d=T[s,'Warthog'];t=d.time_s;axes[0,j].plot(t,d.reference_mps,color='#125da6');axes[0,j].set_title(['Payload and grade','Noise and motor lag'][j]);axes[0,j].set_ylabel('Reference (m/s)')
 grade=(2.5*((t>=63)&(t<100))) if j==0 else 1.*((t>=54)&(t<93));axes[1,j].plot(t,grade,color='#c54c34');axes[1,j].set_ylabel('Road grade (%)');axes[1,j].set_xlabel('Time (s)')
for ax in axes.flat:ax.grid(alpha=.22)
fig.tight_layout();save(fig,'Fig04_test_profiles')
Q=pd.read_csv(SRC/'physical_tuning.csv');fig,ax=plt.subplots(figsize=(7.8,3.7));ax.scatter(Q.RMSE_mps,Q.TorqueTV_Nm,s=70,color='#125da6')
for _,r in Q.iterrows():ax.annotate(str(int(r.candidate)),(r.RMSE_mps,r.TorqueTV_Nm),xytext=(6,5),textcoords='offset points')
ax.scatter([.1242787622],[174.73286],marker='s',color='#888888',label='Previous Warthog');ax.scatter([.03388236704],[195.1164899],s=140,facecolors='none',edgecolors='#c54c34',lw=2,label='Selected candidate 46');ax.set(xlabel='Development RMSE (m/s)',ylabel='Applied torque variation (N m)');ax.legend(fontsize=9);ax.grid(alpha=.2);fig.tight_layout();save(fig,'Fig05_tuning')
for s,fn in [(scenarios[0],'Fig06_payload_tracking'),(scenarios[1],'Fig07_noise_tracking')]:
 fig,axs=plt.subplots(3,1,figsize=(9.5,7),sharex=True);d=T[s,'PI'];axs[0].plot(d.time_s,d.reference_mps,color='#999999',lw=2.7,label='Reference')
 for n,l,c,ls in zip(names,labels,colors,styles):
  d=T[s,n];axs[0].plot(d.time_s,d.speed_mps,color=c,ls=ls,lw=1.1,label=l);axs[1].plot(d.time_s,d.reference_mps-d.speed_mps,color=c,ls=ls,lw=1);axs[2].plot(d.time_s,d.applied_torque_Nm,color=c,ls=ls,lw=.75)
 for ax,yl in zip(axs,['Speed (m/s)','Tracking error (m/s)','Applied torque (N m)']):ax.set_ylabel(yl);ax.grid(alpha=.2)
 axs[0].legend(ncol=5,loc='upper center',bbox_to_anchor=(.5,1.25),fontsize=9);axs[2].set_xlabel('Time (s)');fig.tight_layout();save(fig,fn)
fig,axs=plt.subplots(1,2,figsize=(9.5,4));pos=np.arange(3);w=.19
for j,(field,yl) in enumerate([('RMSE_mps','RMSE (m/s)'),('TorqueTV_Nm','Applied torque variation (N m)')]):
 for i,(n,l,c) in enumerate(zip(names,labels,colors)):
  vals=[M[(M.scenario==s)&(M.controller==n)].iloc[0][field] for s in scenarios];axs[j].bar(pos+(i-1.5)*w,vals,width=w,color=c,label=l)
 axs[j].set(xticks=pos,xticklabels=['Payload/grade','Noise 8041','Noise 8042'],ylabel=yl);axs[j].grid(axis='y',alpha=.2)
axs[0].legend(ncol=2,fontsize=9);fig.tight_layout();save(fig,'Fig08_metric_tradeoffs')
fig,axs=plt.subplots(3,2,figsize=(9.5,6.6),sharex=True)
for j,s in enumerate(scenarios[:2]):
 d=T[s,'Warthog'];t=d.time_s;axs[0,j].plot(t,d.effective_alpha,color='#125da6',label='MFAC weight');axs[0,j].plot(t,d.estimator_confidence,color='#888888',lw=.7,label='Confidence');axs[0,j].set_title(['Payload and grade','Noise seed 8041'][j]);axs[1,j].plot(t,d.sensitivity_a,color='#125da6',label='a');axs[1,j].plot(t,d.sensitivity_b,color='#c54c34',label='b');axs[2,j].plot(t,d.prediction_residual,color='#26845b',lw=.75);axs[2,j].set_xlabel('Time (s)')
axs[0,0].set_ylabel('Weight / confidence');axs[1,0].set_ylabel('Estimated coefficients');axs[2,0].set_ylabel('Prediction residual');axs[0,0].legend(fontsize=8,ncol=2);axs[1,0].legend(fontsize=8,ncol=2)
for a in axs.flat:a.grid(alpha=.2)
fig.tight_layout();save(fig,'Fig09_adaptation')
fig,axs=plt.subplots(2,1,figsize=(9.5,5),sharex=True)
for n,l,c,ls in zip(names,labels,colors,styles):
 d=T[scenarios[0],n];axs[0].plot(d.time_s,d.SOC_pct,color=c,ls=ls,label=l);axs[1].plot(d.time_s,d.MG2_power_kW,color=c,ls=ls,lw=1)
axs[0].legend(ncol=4);axs[0].set_ylabel('Battery SOC (%)');axs[1].set_ylabel('MG2 power (kW)');axs[1].set_xlabel('Time (s)')
for a in axs:a.grid(alpha=.2)
fig.tight_layout();save(fig,'Fig10_physical_signals')
# Wrapper source is documented as a schematic, not a screenshot.
fig,ax=plt.subplots(figsize=(9.5,4.7));ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
box(ax,.02,.67,.21,.16,'Speed and reference\nrpm → m/s');box(ax,.02,.38,.21,.16,'Applied torque delay\nand brake conversion');box(ax,.02,.09,.21,.16,'Measurement noise\nfrom workspace');box(ax,.34,.35,.28,.24,'Level 2 MATLAB S function\nwh_sfun_incremental\nselected mode 1 to 4',fill='#eaf1fa');box(ax,.73,.43,.24,.16,'Controller output\nto MG2 supervisor');box(ax,.73,.13,.24,.16,'State and diagnostic\nlogging')
arr(ax,(.23,.75),(.34,.52),via=[(.29,.75),(.29,.52)]);arr(ax,(.23,.46),(.34,.46));arr(ax,(.23,.17),(.34,.40),via=[(.29,.17),(.29,.40)]);arr(ax,(.62,.51),(.73,.51));arr(ax,(.62,.40),(.73,.21),via=[(.67,.40),(.67,.21)]);ax.text(.5,.91,'Current wrapper design reconstructed from executable source',ha='center',fontsize=11);save(fig,'FigA2_wrapper_schematic')
summary={'n_complete_traces':12,'max_command_violations':int(M.CommandViolationSamples.max()),'noise_seeds':[8041,8042], 'selected_candidate':46,'Hinf_state_eigenvalues':np.linalg.eigvals(P['A']).tolist()}
(OUT/'code/verification.json').write_text(json.dumps(summary,indent=2));print(N);print('Created',len(list(FIG.glob('*.png'))),'figures')
