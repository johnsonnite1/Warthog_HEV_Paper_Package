Johnson Abiola

Department of Mechatronics Engineering, College of Engineering,
Bells University of Technology, Ota, Nigeria

## Abstract

Power-split hybrid electric vehicles require speed controllers that balance disturbance rejection with acceptable torque activity under uncertain loads and noisy measurements. This study implements the Warthog controller, a hybrid of H∞ and model-free adaptive control (MFAC), in a nonlinear Simscape vehicle. The controller blends an H∞ command increment and a regularized MFAC increment from a common previous applied-torque reference. A filtered confidence gate adjusts the adaptive contribution using excitation, prediction residual and tracking error. Offline tuning uses 96 local-model screening settings and four physical-model candidates; the selected parameters are frozen before evaluation. Four sampled controllers—PI, H∞, MFAC and Warthog—are compared using a 150 s payload/grade case and two complete realizations of a noisy, lagged case. Under a 25% mass increase and 2.5% road grade, Warthog achieves an RMSE of 0.06821 m/s, improving on PI, H∞ and MFAC by 36.27%, 86.29% and 69.09%, respectively. Across two noise seeds, Warthog reduces applied-torque total variation by 53.02% relative to PI, while PI retains the smaller tracking error. All twelve reported evaluation traces satisfy the applied-torque amplitude check. The findings establish a condition-dependent tracking–torque tradeoff for the tested implementation rather than universal superiority. Analytical results establish controller-output bounds and clarify the increment-blending mechanism; nonlinear closed-loop stability remains a separate requirement.

Keywords: power-split hybrid electric vehicle; speed tracking; H∞ control; model-free adaptive control; adaptive blending; torque variation.

## 1 Introduction

Longitudinal speed tracking connects a requested driving trajectory to the torque delivered by the vehicle powertrain. In a power-split hybrid electric vehicle (HEV), this task interacts with electromechanical coupling, road-load changes, motor dynamics and supervisory decisions. An accurate controller may require considerable torque activity when speed measurements are noisy, whereas a smoother response may accept greater tracking error. The engineering question is therefore not simply which controller produces the smallest error, but how its error and control activity change across operating conditions. The MathWorks power-split HEV provides a modular physical environment for studying this interaction [1].

Robust and adaptive methods address different parts of this problem. Xue and Jiao [2] developed a cascade adaptive speed-control scheme for a parallel HEV with electronic throttle control. Zhang et al. [3] studied robust vehicle speed control with road-slope variation, measurement noise and network-induced delay. These works demonstrate that disturbance handling and measurement treatment belong within the speed-control design. They do not imply that a controller tuned at one operating condition will retain the best balance everywhere.

MFAC constructs an online input–output description without requiring a full first-principles plant model. Recent partial-form dynamic-linearization research [4] and a 2024 overview of MFAC for wheeled mobile robots [5] explain the input–output learning perspective used here. In a hybrid vehicle, however, learning must reflect the torque that the plant actually receives. Saturation, brake override and regenerative restrictions can make this differ from an unconstrained controller proposal. Learning from an unexecuted proposal can misrepresent the local input–output relation.

Combining a nominal robust controller with an adaptive component is already an established research direction. Xu et al. [6], for example, combine a model-based sliding-mode law with an MFAC-based compensator for intelligent-vehicle path tracking. Li et al. [7] compare MFAC against H∞ and proportional–integral methods in a wind-turbine application. Abiola et al. [8] investigate hybrid control for quadrotor stabilization and trajectory tracking, while Abiola et al. [9] demonstrate a learning-based energy-management application with attention to transition smoothness. These studies motivate structured comparisons and application-specific hybridization; they are not evidence that any H∞–MFAC combination is automatically novel or superior.

This study examines an HEV implementation of the Warthog controller. Its technical focus is the combination of actuator-referenced command increments, a projected partial-form adaptive predictor and a filtered confidence-dependent blend within the retained MG2 supervisory interface. The contribution is threefold. First, the implementation makes the executed actuator command the common reference for both branch proposals. Second, it derives bounds and an algebraic identity that explain the blend without extending a local H∞ certificate to the entire nonlinear hybrid. Third, it documents tuning and a four-controller comparison on complete, matched disturbance and noise cases, exposing both tracking improvements and torque-activity costs. The paper does not claim the invention of robust–adaptive hybridization in general.

## 2 Related work and research position

Vehicle speed regulation, energy management and path tracking are related but distinct tasks. Liu et al. [10] apply robust design to MFAC-based plug-in HEV energy management, where the responses include fuel consumption and terminal battery charge. Their result establishes that MFAC is already used in HEVs; it does not evaluate the MG2 speed loop considered here. Similarly, path-tracking compensation in [6] addresses lateral and heading errors rather than the longitudinal speed command and applied-torque feedback used in this study. This distinction supports a specific application and architecture claim, not an unqualified first-use claim.

Recent MFAC research also addresses initialization sensitivity, uncertainty and anti-windup. Heydari et al. [11] incorporate an alternative cost function and anti-windup strategy. Such work shows that parameter projection and actuator constraints are established concerns. In the present implementation, the bounded adaptive increment is blended with an H∞ increment before a common limiter, and the previous applied torque is returned from downstream supervisory logic. The novelty position therefore rests on the implemented arrangement and its HEV evaluation, with the analytical identity below supplying a precise explanation of the mechanism.

Table 1 Research position relative to selected literature

Table 1 Research position relative to selected literature
Work | Relevant method or task | Distinction in this study
[2] Xue and Jiao | Cascade adaptive HEV speed control | Adaptive increment blending at the MG2 interface
[3] Zhang et al. | Robust speed control with slope, noise and delay | Applied torque learning and online blend scheduling
[6] Xu et al. | SMC plus MFAC for vehicle path tracking | H∞ plus MFAC for longitudinal HEV tracking
[10] Liu et al. | Robust MFAC energy management | Speed tracking rather than fuel or SOC optimization
[11] Heydari et al. | Robust MFAC and anti windup | Shared actuator reference for two command increments



The name Warthog serves as a behavioural design metaphor: a protective robust branch, an adaptive response to changing conditions and bounded action. These labels help interpret the controller, but the engineering evidence is supplied by its equations and simulation traces. The method is not a zoological model or an animal-inspired population optimizer.

## 3 Physical model and control objective

### 3.1 Power split HEV and supervisory interface

The plant is the MathWorks Simscape power-split HEV, release 1.6.1, executed in MATLAB R2023a [1]. Its engine, MG1, MG2, planetary power split, reduction gearing, battery, DC–DC converter and longitudinal vehicle retain the supplied physical implementation. Figure 1(a) summarizes the HEV system power paths, while Figure 1(b) shows a genuine Simulink export of the plant topology from the implementation workflow. The experiment modifies the sampled speed-controller interface in the MG2 subsystem and retains the existing powertrain supervisor. This is a speed-loop study, rather than an optimization of engine scheduling or power split.

Figure 1(a). System-level power-flow diagram of the power-split HEV. Blue paths denote mechanical coupling and green paths denote electrical exchange; electrical conversion stages are grouped for clarity. This is a schematic based on the model architecture [1].

![Figure 1(a). System-level power-flow diagram of the power-split HEV. Blue paths denote mechanical coupling and green paths denote electrical exchange; electrical conversion stages are grouped for clarity. This is a schematic based on the model architecture [1].](figures/Fig01a_HEV_system.png)

Figure 1(b). Genuine Simulink export of the MathWorks power-split HEV implementation. The physical plant topology is retained; the research controller is inserted in the MG2 speed loop. Source model: MathWorks [1].

![Figure 1(b). Genuine Simulink export of the MathWorks power-split HEV implementation. The physical plant topology is retained; the research controller is inserted in the MG2 speed loop. Source model: MathWorks [1].](figures/Fig01_real_HEV.png)

For interpretation, the longitudinal force balance can be written as

(1) m dv/dt = F_drive − F_brake − F_road(v) − m g sin(θ).

Here m is vehicle mass, v is longitudinal speed, F_drive is effective axle driving force, F_brake is braking force, g is gravitational acceleration and θ is road angle. The road-load approximation is F_road(v) = A + B(3.6v) + C(3.6v)², using the vendor parameters defined in km/h. Road grade is specified as 100 tan(θ) percent. Equation (1) explains the disturbance channels; it does not replace the nonlinear Simscape plant used to obtain results. The mass perturbation changes vehicle.mass_kg while leaving the vendor road-load coefficients unchanged.

Table 2 Physical model and numerical settings

Table 2 Physical model and numerical settings
Quantity | Value | Meaning
Nominal mass | 1575 kg | Vendor vehicle parameter
Effective rolling radius | 0.30 m | Speed conversion radius
Road load A, B, C | 175; 0; 0.032 | N; N/(km/h); N/(km/h)²
MG2 torque and power limits | 165 N m; 55 kW | Vendor motor parameters
Nominal MG2 response time | 0.05 s | Lag varied in evaluation cases
Battery voltage and capacity | 200 V; 25 kWh | Abstract high voltage battery
Initial battery SOC | 70% | Reset for each physical run
Controller and logging interval | 0.02 s | 50 Hz sampled controllers
Maximum solver step | 0.01 s | Normal simulation mode
Relative and absolute tolerance | 10⁻⁵; 10⁻⁷ | Identical across compared runs
Controller torque slew limit | 600 N m/s | Before the existing supervisor



### 3.2 Signals and comparison scope

The measured speed and reference enter the MG2 wrapper in rpm and are converted to m/s with 2πr_w/60, where r_w = 0.30 m. The controller uses normalized speed y = v/30 and normalized torque u = τ/165. Measurement noise is added to speed before the controller filter. Performance error is calculated against the logged true speed, so sensor noise is not directly counted as physical tracking error. The applied-torque feedback is taken after the existing brake and battery-level logic and delayed by one controller sample.

The quantitative evaluation comprises three complete matched cases: one payload/grade condition and two realizations of one noisy, lagged condition. A trace is eligible for the four-way comparison when the complete 150 s record is available for every compared controller. The reported evaluation therefore contains twelve traces, each with 7501 samples. Its conclusions apply to these specified conditions; they do not establish performance throughout the vehicle operating envelope. The comparison concerns the four sampled research configurations PI, H∞, MFAC and Warthog, rather than a claim of improvement over every possible driver implementation.

## 4 Warthog controller design

### 4.1 Normalization and measurement filtering

Let k denote the sample index, T_s the sample interval, r_k the normalized speed reference, y_k the normalized measured speed and u^a_{k−1} the previous normalized applied torque. The causal speed filter and tracking error are

(2) y^f_k = y^f_{k−1} + β_y(y_k − y^f_{k−1}),   e_k = r_k − y^f_k,   β_y = T_s/(τ_y + T_s).

The controller computes Δy_k = y^f_k − y^f_{k−1} and Δu_k = u^a_{k−1} − u^a_{k−2}. Using the executed input increments is essential when supervisory logic overrides a previous request. All four research controllers use the same speed-filter time constant τ_y = 0.03 s.

### 4.2 Nominal H infinity branch

A stable local input–output model identified from physical-model simulations near 12 m/s supplies the H∞ design channel. It is used for local synthesis and inexpensive screening, while all reported physical evaluation traces come from the nonlinear Simscape model. Mixed-sensitivity synthesis minimizes the weighted closed-loop norm [12]

(3) min_K ‖[ W_e S ; W_u K S ; W_t T ]‖∞,   S = (1 + GK)⁻¹,   T = GK(1 + GK)⁻¹.

The implemented weights are W_e(s) = (s/2 + 4)/(s + 0.04), W_u = 0.2 and W_t(s) = (s + 4)/(0.1s + 40). The saved synthesis returns γ = 2.68583. This is the achieved weighted norm; it is not a claim that a unit weighted-performance bound was satisfied. The fourth-order continuous controller is converted using the Tustin method at T_s = 0.02 s. Its implemented state equations are

(4) x^H_{k+1} = A_H x^H_k + B_H e_k,   h_k = C_H x^H_k + D_H e_k,   Δh_k = h_k − h_{k−1}.

The discrete controller matrices are supplied in Appendix A and in the accompanying numeric parameter file. The H∞ controller uses h_k as its standalone proposal; Warthog uses Δh_k. Thus the H∞ branch supplies a locally designed dynamic correction, while the hybrid law determines how much of that increment reaches the torque request.

### 4.3 Projected partial form adaptive predictor

The adaptive branch uses a one-step increment predictor inspired by partial-form dynamic linearization [4]. With parameters a, b and d, the observed output increment is locally approximated by

(5) Δy_k ≈ a_{k−1} Δy_{k−1} + b_{k−1} Δu_k + d_{k−1};   ε_k = Δy_k − a_{k−1}Δy_{k−1} − b_{k−1}Δu_k − d_{k−1}.

The coefficients describe the sampled local input–output behaviour and are not identified physical inertia or motor constants. The residual ε_k is evaluated using the previous estimates. An update is accepted only when mechanical braking is inactive, |Δu_k| > u_min and |ε_k| < ε_max. For an accepted update, define φ_k = [Δy_{k−1}, Δu_k]ᵀ and compute

(6) [a⁺_k, b⁺_k]ᵀ = Π_Ω{[a_{k−1}, b_{k−1}]ᵀ + η φ_k ε_k/(μ + φ_kᵀφ_k)}.

The componentwise projection set is Ω = {−0.995 ≤ a ≤ 0.995, 10⁻⁶ ≤ b ≤ 0.2}. A nonfinite update or nonpositive candidate b is rejected before projection; a rejected update retains the previous parameters. The positive control-direction assumption is therefore explicit and applies to the chosen operating channel. An enabled bounded disturbance-increment estimate is updated as

(7) d⁺_k = clip(d_{k−1} + k_d ε_k, −d_max, d_max).

During brake override the estimator parameters and disturbance estimate are held. The MFAC increment uses the accepted or held parameters, the reference change Δr_k and the filtered current error:

(8) Δm_k = clip{ ρ b⁺_k [Δr_k + κ e_k − a⁺_k Δy_k − d⁺_k]/[λ + (b⁺_k)²], −δ_max, δ_max }.

The regularizer λ prevents an unbounded division by a small sensitivity estimate. The gain κ weights current tracking error; ρ scales adaptation-driven control action and δ_max = 0.05 limits the normalized increment. The standalone MFAC proposal is u^a_{k−1} + Δm_k. The online update does not require the full vehicle model, although Warthog as a whole remains a model-assisted hybrid because of its H∞ branch.

### 4.4 Confidence gate and increment blend

Excitation and prediction consistency determine an engineering confidence score. This is a heuristic reliability indicator, not a probability or a formal confidence interval. Let z_k denote a low-pass filtered squared applied-input increment and b_k^br indicate active mechanical braking. Then

(9) z_k = z_{k−1} + β_c[(Δu_k)² − z_{k−1}],   c_k = (1 − b_k^br) min(1, √(z_k/z_min)) exp[−(ε_k/ε_max)²].

Here β_c = T_s/(τ_c + T_s). A residual that exceeds ε_max forces c_k = 0. A low-pass tracking-error signal e^s_k and the blend are updated according to

(10) e^s_k = e^s_{k−1} + β_e(e_k − e^s_{k−1}),   α*_k = c_k α_max (e^s_k)²/[(e^s_k)² + e_b²].

(11) α_k = clip{α_{k−1} + β_α(α*_k − α_{k−1}), 0, α_max},   β_α = T_s/(τ_α + T_s).

The Warthog torque proposal is

(12) u^raw_k = u^a_{k−1} + (1 − α_k)Δh_k + α_k Δm_k.

Equation (12) is the defining implemented blend. Both branch increments start from the same previous applied torque, instead of combining two independently accumulated absolute torque histories. Figure 2 shows the closed-loop signal arrangement, and Figure 3 shows the online sequence.

Figure 2. Closed-loop design of the implemented H∞–MFAC hybrid. This is an engineering schematic; the physical-model screenshot is shown separately in Figure 1(b).

![Figure 2. Closed-loop design of the implemented H∞–MFAC hybrid. This is an engineering schematic; the physical-model screenshot is shown separately in Figure 1(b).](figures/Fig02_closed_loop.png)

Figure 3. Online controller flowchart. Parameter search precedes evaluation; the online loop updates estimator states and blending weight without retuning its fixed hyperparameters.

![Figure 3. Online controller flowchart. Parameter search precedes evaluation; the online loop updates estimator states and blending weight without retuning its fixed hyperparameters.](figures/Fig03_algorithm_flow.png)

### 4.5 Actuator limits and sampled baselines

Let ℓ_{k−1} be the previous limited controller request and R = 600T_s/165 its normalized one-step slew allowance. The controller output sent to the supervisor is

(13) u^c_k = clip{clip(u^raw_k, ℓ_{k−1} − R, ℓ_{k−1} + R), −1, 1}.

The supervisor can subsequently set or restrict the applied torque, for example during mechanical braking or a low battery state. The resulting applied signal is used in (5), (8) and (12). Therefore the rate bound in (13) pertains to the controller request; a supervisory override can change the applied torque more abruptly. Applied-torque total variation remains the evaluation measure because it includes this interaction.

The sampled PI baseline uses u^raw_k = K_p e_k + I_k with I_{k+1} = clip{I_k + T_s[K_i e_k + k_aw(u^a_{k−1} − ℓ_{k−1})], −1, 1}. Its gains are K_p = 14.2240965, K_i = 4.2088851 and k_aw = 0.5 in normalized units. Standalone H∞ uses h_k, and standalone MFAC uses u^a_{k−1} + Δm_k. All pass through the same limiter and retained supervisor. The final Warthog hyperparameters differ from the standalone MFAC baseline because they were optimized for the hybrid, as documented below. The comparison is consequently between fixed implemented configurations, not equally optimized global optima.

### 4.6 Analytical properties and their scope

Proposition 1 concerns bounds enforced directly by the implementation. If α_0 ∈ [0, α_max], z_0 ≥ 0 and all filter coefficients lie in (0,1], then z_k ≥ 0, 0 ≤ c_k ≤ 1 and 0 ≤ α_k ≤ α_max for every finite sample. If the initial predictor estimates lie in Ω and |d_0| ≤ d_max, projection or parameter holding keeps those estimates inside their prescribed bounds. For finite branch proposals, (13) gives |u^c_k| ≤ 1 and |u^c_k − ℓ_{k−1}| ≤ R, provided |ℓ_{k−1}| ≤ 1. In physical units these correspond to 165 N m and 12 N m per 0.02 s sample. The proof follows from convex low-pass updates and interval projection, with induction on the sample index. This is a controller-output and parameter-boundedness statement.

Proposition 2 explains the increment construction. Consider an absolute-output blend q_k = (1 − α_k)h_k + α_k m_k. Its increment contains an additional term:

(14) q_k − q_{k−1} = (1 − α_k)Δh_k + α_kΔm^abs_k + (α_k − α_{k−1})(m_{k−1} − h_{k−1}).

By direct subtraction, the last term arises from moving the weight between unequal absolute branch histories. Equation (12) instead constructs both proposals from u^a_{k−1}; it therefore has no explicit weight-change times absolute-history-gap term. This identity does not guarantee smaller torque variation in every case: changing α_k still changes the increment mixture, and branch increments, measurement noise and supervision remain relevant.

The eigenvalues of the saved A_H are approximately 0.999200, 0.649065, −0.712249 and −0.600001. Consequently, the H∞ controller state is input-to-state bounded for bounded e_k. This conditional controller-state property and the local synthesis result do not prove global stability or asymptotic tracking of the nonlinear adaptive HEV. In particular, bounded requested torque alone does not establish bounded tracking error. The simulation analysis below is empirical evidence within the stated test conditions, not a substitute for a composite nonlinear stability theorem.

## 5 Tuning and experimental protocol

### 5.1 Offline parameter selection

The local model was used to screen 96 deterministic settings using random seed 28417: the previous Warthog setting, six directed recipes and 89 random settings. Each setting was ranked on two inexpensive local-model conditions. Only the four shortlisted settings were newly simulated on the physical HEV for the 120 s development trajectory. The earlier physical Warthog record remained eligible as the incumbent. The composite development objective is

(15) J = E/min(E_PI,E_MFAC) + 0.15 A/min(A_PI,A_MFAC) + 0.10 V/V_PI + 2[max(0,V/V_PI − 1.25)]².

E denotes RMSE, A denotes integral absolute error (IAE) and V denotes applied-torque total variation. Screening normalizes against local-model baselines; physical selection separately normalizes against the actual development baselines. Surrogate and physical scores are not pooled. The selected candidate minimizes the physical composite score among the evaluated candidates and incumbent. This bounded search is practical tuning, not a claim of globally optimal parameters.

Table 3 Offline search ranges and selected Warthog values

Table 3 Offline search ranges and selected Warthog values
Parameter | Random search range | Selected value
Tracking fraction κ | 0.008 to 0.30 | 0.0166072
Control scale ρ | 0.04 to 0.25 | 0.244701
Regularizer λ | 2×10⁻⁶ to 3×10⁻⁴ | 6.80808×10⁻⁶
Maximum MFAC weight α_max | 0.45 to 0.98 | 0.524948
Normalized error band e_b | 5×10⁻⁵ to 0.003 | 1.06330×10⁻⁴
Blend time constant τ_α | 0.08 to 0.8 s | 0.333568 s
Confidence time constant τ_c | 0.3 to 3 s | 2.09510 s
Excitation level z_min | 10⁻¹² to 3×10⁻⁸ | 3.60071×10⁻⁹
Estimator learning gain η | 0.03 to 0.3 | 0.0704166
Initial output coefficient a_0 | 0.50 to 0.98 | 0.611563



Random positive scale parameters are sampled log-uniformly; α_max and a_0 are sampled uniformly. The directed recipes are preserved in the automation source. Other fixed adaptive settings are μ = 10⁻⁴, b_0 = 0.0019220466, d_max = 0.03, k_d = 0.1, u_min = 10⁻⁵, ε_max = 0.02 and τ_e = 0.05 s. The standalone MFAC retains κ = 0.02, ρ = 0.1, λ = 10⁻⁵, η = 0.3 and a_0 = 0.7. H∞ matrices, PI gains, measurement-filter settings and actuator limits are not weakened during the Warthog search.

Table 4 Actual physical development results

Table 4 Actual physical development results
Candidate | RMSE m/s | IAE m | Torque TV N m | Score or status
Previous Warthog | 0.124279 | 12.2245 | 174.733 | Incumbent
46 | 0.033882 | 1.8417 | 195.116 | 0.64843
41 | 0.032353 | 1.7242 | 237.567 | 0.65400
16 | 0.032458 | 1.8314 | 248.495 | 0.68782
86 | 0.043840 | 2.1911 | 220.885 | 0.81447



Figure 4 and Table 4 show why candidate 46 was selected even though candidate 41 has the smallest development RMSE. Candidate 46 combines RMSE = 0.0338824 m/s with lower torque variation, producing J = 0.64843 compared with 0.65400 for candidate 41. Against the saved development PI and MFAC RMSE values of 0.0716849 and 0.0721294 m/s, candidate 46 improves tracking by 52.73% and 53.03%, respectively. Its torque variation is 7.79% above development PI. These are tuning results, not held-out performance estimates.

Figure 4. Physical development tradeoff for the four screened candidates and previous Warthog incumbent. The selected point minimizes the stated composite objective.

![Figure 4. Physical development tradeoff for the four screened candidates and previous Warthog incumbent. The selected point minimizes the stated composite objective.](figures/Fig05_tuning.png)

### 5.2 Matched evaluation cases

After selection, the numerical controller parameters are frozen. Each physical run resets the plant and controller states. Table 5 defines the reported evaluation; Figure 5 shows its reference and road-grade profiles. The payload/grade condition changes mass and MG2 lag simultaneously, so its results establish performance under the combined perturbation rather than isolating a causal contribution from each component. The two noise runs use exactly the same reference and disturbance settings with different random seeds. Each seed is shared across the four controllers.

Table 5 Complete matched evaluation conditions

Table 5 Complete matched evaluation conditions
Case | Mass and MG2 lag | Grade profile | Speed noise
Payload and grade | 1.25m₀ = 1968.75 kg; 1.3τ₀ = 0.065 s | 2.5% from 63 to 100 s | None; seed 6122
Noise realization 1 | 1.10m₀ = 1732.5 kg; 2τ₀ = 0.10 s | 1% from 54 to 93 s | σ = 0.03 m/s; seed 8041
Noise realization 2 | Same as realization 1 | Same as realization 1 | σ = 0.03 m/s; seed 8042



For the payload/grade trajectory, time knots in seconds are [0, 4, 19, 33, 51, 68, 87, 103, 121, 137, 150] and corresponding speed knots in m/s are [0, 0, 8, 8, 14, 14, 5, 5, 11, 11, 0]. The noisy trajectory uses times [0, 6, 24, 39, 58, 75, 96, 111, 131, 143, 150] and speeds [0, 0, 10, 10, 16, 16, 7, 7, 13, 13, 0]. Linear interpolation constructs both references. Independent Gaussian speed-noise samples are generated at T_s and supplied through the common measurement interface. Development uses a different 120 s reference with a 1.5% grade from 55 to 85 s.

Figure 5. Declared speed references and grade inputs for the reported evaluation. Two seeds repeat the same noise/lag condition.

![Figure 5. Declared speed references and grade inputs for the reported evaluation. Two seeds repeat the same noise/lag condition.](figures/Fig04_test_profiles.png)

### 5.3 Metrics and numerical verification

Let E_v(t) = v_ref(t) − v_true(t), T = 150 s and τ^a_k be the logged applied torque. The principal metrics are

(16) RMSE = √[(1/T)∫₀ᵀ E_v(t)²dt],   IAE = ∫₀ᵀ |E_v(t)|dt,   TV_τ = Σₖ |τ^a_k − τ^a_{k−1}|.

Peak absolute error, torque RMS, battery SOC endpoints and a filtered jerk measure supplement these metrics. Jerk is computed by applying a common five-sample moving mean to true speed, followed by two numerical derivatives at 0.02 s; its RMS is integrated over the full interval. It is a numerical motion-smoothness indicator rather than a measured passenger-comfort outcome. Torque TV is evaluated at the same logging interval for every controller and depends on that interval. Full-trace metrics include acceleration, braking and supervisory transitions.

All twelve evaluation CSV traces were independently checked for the required duration and strictly increasing timestamps. Recalculated RMSE agreed with the saved MATLAB values to floating-point precision. The applied-torque amplitude test counts samples above 165 N m plus a 10⁻⁶ N m numerical allowance. Matching the logged values verifies metric consistency; it does not validate the physical accuracy of the abstract vehicle or establish real-time execution performance.

## 6 Results and discussion

### 6.1 Tracking under payload and road grade

Table 6 Full duration payload and grade results

Table 6 Full duration payload and grade results
Controller | RMSE m/s | IAE m | Peak error m/s | Torque TV N m | Jerk RMS m/s³
PI | 0.10704 | 9.7885 | 0.4449 | 364.93 | 0.2206
H∞ | 0.49766 | 69.5947 | 0.7410 | 325.68 | 0.1908
MFAC | 0.22067 | 19.3709 | 1.0773 | 526.69 | 0.1863
Warthog | 0.06821 | 4.6449 | 0.4231 | 414.59 | 0.2338



Warthog achieves the smallest RMSE and IAE among the four research configurations in the combined payload/grade case. Its RMSE of 0.0682133 m/s is 36.27% below PI, 86.29% below H∞ and 69.09% below MFAC. Its IAE is 4.64488 m, compared with 9.78855 m for PI. The corresponding speed, error and torque trajectories are plotted in Figure 6, so the aggregate comparison can be assessed alongside the transient response.

The improvement is accompanied by a cost. Warthog torque TV is 414.592 N m, versus 364.934 N m for PI and 325.680 N m for H∞. Warthog therefore uses 13.61% more applied-torque variation than PI and 27.30% more than H∞, while requiring 21.28% less than standalone MFAC. Its jerk RMS of 0.23376 m/s³ is also higher than the other three values in this case. Thus the strongest supported statement is improved tracking with an increased motion/control-activity burden relative to PI and H∞, rather than improved performance in every metric.

Figure 6. Completed payload/grade simulation for the four sampled controllers. The plots include true speed, physical tracking error and applied MG2 torque over the full 150 s.

![Figure 6. Completed payload/grade simulation for the four sampled controllers. The plots include true speed, physical tracking error and applied MG2 torque over the full 150 s.](figures/Fig06_payload_tracking.png)

### 6.2 Tracking and torque activity under noisy measurements

Figure 7. Complete noisy, lagged simulation for seed 8041. Seed 8042 is included in the quantitative summary; both seeds use identical physical settings and reference trajectories.

![Figure 7. Complete noisy, lagged simulation for seed 8041. Seed 8042 is included in the quantitative summary; both seeds use identical physical settings and reference trajectories.](figures/Fig07_noise_tracking.png)

Table 7 Noise and lag results as mean ± sample standard deviation across two seeds

Table 7 Noise and lag results as mean ± sample standard deviation across two seeds
Controller | RMSE m/s | IAE m | Torque TV N m | Jerk RMS m/s³
PI | 0.13827 ± 0.00038 | 9.90276 ± 0.10587 | 6171.58 ± 15.87 | 0.41180 ± 0.00129
H∞ | 0.45543 ± 0.00052 | 58.23417 ± 0.11792 | 5183.96 ± 33.97 | 0.37942 ± 0.00051
MFAC | 1.24423 ± 0.00119 | 125.29872 ± 0.42341 | 449.98 ± 0.52 | 0.41560 ± 0.00061
Warthog | 0.35320 ± 0.00560 | 30.46370 ± 0.14854 | 2899.20 ± 19.66 | 0.39325 ± 0.00062



The noisy, lagged condition changes the ranking. PI has the smallest mean RMSE, 0.138269 m/s, whereas Warthog gives 0.353202 m/s. Warthog therefore incurs approximately 155.45% greater RMSE than PI, while improving on H∞ and MFAC by approximately 22.45% and 71.61%, respectively. Standalone MFAC has the smallest torque TV in this condition but also the largest tracking error. These simultaneous results prevent a useful comparison from being reduced to one preferred metric.

Warthog mean torque TV is 2899.20 N m, compared with 6171.58 N m for PI and 5183.96 N m for H∞. The respective reductions are 53.02% and 44.07%. This provides a concrete control-activity benefit relative to the more accurate PI configuration, but Warthog still has considerably more variation than MFAC at 449.98 N m. Warthog mean jerk RMS is 0.39325 m/s³, about 4.50% lower than PI and slightly higher than H∞. Reduced torque TV therefore should not be treated as equivalent to a general comfort or energy-efficiency improvement.

Figure 8. RMSE and torque-TV comparison across the three complete matched cases. The two noise columns are repeated realizations of one prescribed scenario, not independent operating regimes.

![Figure 8. RMSE and torque-TV comparison across the three complete matched cases. The two noise columns are repeated realizations of one prescribed scenario, not independent operating regimes.](figures/Fig08_metric_tradeoffs.png)

The two-seed standard deviations indicate the variation observed in these two realizations only. They are insufficient for reliable tail-risk estimates, formal significance testing or a general noise-robustness distribution. Figure 8 shows that the tracking–torque tradeoff is consistent across the two available noise realizations, while the size of that benefit remains conditional on the chosen noise amplitude, filter, motor lag and sampled baselines.

### 6.3 Interpretation of the adaptive hybrid

Figure 9 shows the Warthog weight, estimator coefficients and residual for the payload and noisy cases. The effective MFAC weight is bounded by α_max = 0.524948, so the H∞ increment retains at least 47.51% of the mixture weight. Neither the weight alone nor a fitted coefficient proves that one branch causes the observed improvement. The gate combines filtered excitation, residual consistency and error magnitude; its recorded variation confirms that the executed controller is an adaptive blend rather than a fixed convex combination.

Figure 9. Logged Warthog adaptation signals from the completed payload/grade and seed-8041 simulations. Confidence is an engineering gate; the estimated coefficients are local input–output parameters.

![Figure 9. Logged Warthog adaptation signals from the completed payload/grade and seed-8041 simulations. Confidence is an engineering gate; the estimated coefficients are local input–output parameters.](figures/Fig09_adaptation.png)

The payload result is consistent with the intended division of labour: the local robust branch supplies a structured correction and the adaptive increment adjusts the command using executed torque and current measured behaviour. Under noise and increased motor lag, the same configuration reduces torque activity relative to PI while accepting a larger error. Because there is no matched fixed-weight ablation in the reported dataset, the results do not isolate the incremental blend, confidence gate and offline parameter tuning as separate causal improvements. The paper evaluates their combined implemented configuration.

The Warthog metaphor can be used carefully here. “Protective action” describes the retained robust branch and hard command limits; “adaptive response” describes the measured-data update; and “restrained action” describes the filtered mixing law. These descriptions explain the name and design intention. They do not turn a tracking disadvantage into an advantage, or establish a biological reason for any metric. The quantitative conclusions remain those in Tables 6 and 7.

### 6.4 Physical signals and practical implications

Figure 10 reports battery SOC and MG2 mechanical power for the payload/grade case. The small SOC changes arise within a short simulation using the supplied abstract battery model. The present controller does not optimize fuel consumption, engine operating points, battery degradation or the energy-management policy. Accordingly, a smaller torque TV or a slightly different terminal SOC cannot establish a fuel-economy benefit.

Figure 10. Battery SOC and MG2 mechanical power during the completed payload/grade case. These auxiliary signals document physical-model behaviour rather than an energy-economy objective.

![Figure 10. Battery SOC and MG2 mechanical power during the completed payload/grade case. These auxiliary signals document physical-model behaviour rather than an energy-economy objective.](figures/Fig10_physical_signals.png)

All reported evaluation traces contain zero applied-torque amplitude violations under the stated test. This supports correct enforcement of the amplitude envelope in these runs. The studies in [2], [3] and [6] address different vehicle models and uncertainties, so their published numerical improvements are not used as direct head-to-head benchmarks. The appropriate comparison is the matched in-model experiment reported here. For an application prioritizing low tracking error under increased load, the tested Warthog configuration is attractive relative to the sampled baselines. Under noisy measurements, PI is preferable for accuracy, while Warthog provides a lower-torque-variation alternative if its larger error remains acceptable.

## 7 Limitations and research implications

The findings are based on an abstract nonlinear Simscape model, three complete matched cases and one tuned hybrid configuration. Complete-case reporting defines the available comparison set and does not establish successful operation at other speeds, profiles or initial conditions. The noise case has two realizations, and mass, road grade and motor lag are varied jointly in the reported stress case. Generalization to steep grades, low charge, reversing, wide speed ranges or different driveline parameters therefore requires additional evidence.

The local model and H∞ synthesis do not provide a global guarantee for the adaptive, constrained vehicle. A useful theoretical extension would establish an input-to-state or practical tracking bound that explicitly includes estimator error, supervisory switching, rate saturation and the time-varying blend. A useful experimental extension would compare separately optimized standalone controllers, a fixed-weight hybrid and gated hybrids under an independently declared broader test set. These extensions would distinguish architecture benefits from hyperparameter-selection benefits. Hardware-in-the-loop testing is also necessary before making real-time implementation claims.

The supported contribution is a reproducible, constrained implementation and its measured operating-condition tradeoff. It is not necessary for the hybrid to dominate every baseline for this contribution to be useful. Its value is clearest when the selection criterion, actuator interface, learning assumptions and performance costs are reported alongside the improvements.

## 8 Conclusion

This study implemented the Warthog H∞–MFAC controller for longitudinal speed tracking of a power-split HEV. An actuator-referenced increment blend combines a local robust controller with a projected adaptive predictor and confidence-dependent scheduling. The implementation preserves the vehicle supervisor and a common sampled comparison interface. A two-stage offline search selected a hybrid configuration before evaluation on the reported disturbance and noise cases.

Under the combined payload/grade condition, Warthog achieved RMSE = 0.06821 m/s, reducing error by 36.27%, 86.29% and 69.09% relative to sampled PI, H∞ and MFAC, respectively. Across two noisy, lagged realizations it reduced applied-torque variation by 53.02% relative to PI, while PI retained the smaller tracking error. These results support the Warthog configuration as a condition-dependent alternative for balancing tracking and torque activity. The enforced command bounds and increment identity clarify its implementation, while broader nonlinear stability and deployment claims require further analysis and testing.

## Data and code availability

The accompanying reproducibility package provides the numeric controller parameters, executable kernel and wrapper source, figure-generation code, scenario definitions, evaluation tables and the twelve complete CSV traces used for the reported comparisons. The MathWorks physical model is available separately from its original distribution [1]. Local screening scores are distinguished from physical simulation results. The source archive retains experimental provenance and historical attempts.

## Appendix A Controller realization and algorithm

The following discrete-time H∞ realization corresponds to normalized input e and normalized command h. Matrix entries are rounded here for readability; the accompanying numeric file retains the saved double-precision values. The matrix order follows the executable kernel state order.

A_H = [[0.9992003198720512, 0.0, 0.0, 0.0], [0.004450285205312217, -0.5999999716441518, 0.00048396453282827714, 4.988551833976571], [2.181715077511275, 1.3901217248909129e-05, -0.7627404380766964, -60.08883797555733], [0.010908575387555231, 6.950608624443458e-08, 0.0011862978096172582, 0.6995558101222448]]

B_H = [[0.03998400639744103], [8.900570410632787e-05], [0.04363430155022469], [0.0002181715077511273]]

C_H = [[555.7774175745473, 0.0035412427146787008, -366.540021512114, -15303.862405140393]]

(AD) D_H = 11.1155483515.

Algorithm 1 gives the online execution order. Projection, holding and logging follow the supplied source exactly; the standalone branches and sampled PI use the same output constraints.

```
Algorithm 1  Online Warthog controller at sample k
Input: reference, measured speed, previous applied torque, brake flag
State: H∞ state, predictor history, a,b,d, confidence and blend filters
1  Normalize signals; update measured-speed low-pass filter.
2  Form e, reference increment, output increment and applied-input increment.
3  Evaluate prediction residual with previous a,b,d; update excitation filter.
4  If brake inactive and excitation/residual guards pass:
      form normalized-gradient parameter candidate;
      reject nonfinite or nonpositive-b candidate; otherwise project a,b.
5  If brake inactive: update bounded disturbance estimate; otherwise hold.
6  Compute confidence and filtered tracking-error scheduling signal.
7  Update and bound MFAC weight alpha.
8  Compute H∞ absolute command and its increment from stored history.
9  Compute and clip the regularized MFAC increment.
10 Blend increments from previous applied torque using Eq. (12).
11 Apply request slew limit and amplitude saturation using Eq. (13).
12 Send torque request to existing MG2 supervisor.
13 Store states/history; log applied torque and adaptation diagnostics.
14 Repeat at the next 0.02 s sample.
```

Figure A1. Genuine Simulink export of the retained vendor PI speed-control subsystem. The sampled PI benchmark used in the numerical comparison is the explicitly defined normalized PI implementation in Section 4.5.

![Figure A1. Genuine Simulink export of the retained vendor PI speed-control subsystem. The sampled PI benchmark used in the numerical comparison is the explicitly defined normalized PI implementation in Section 4.5.](figures/FigA1_real_PI_subsystem.png)

Figure A2. Current research-wrapper design reconstructed from executable source. This schematic distinguishes the active incremental S-function from historical wrapper screenshots; it is not presented as a native Simulink export.

![Figure A2. Current research-wrapper design reconstructed from executable source. This schematic distinguishes the active incremental S-function from historical wrapper screenshots; it is not presented as a native Simulink export.](figures/FigA2_wrapper_schematic.png)

## References

[1] MathWorks, “Hybrid Electric Vehicle Model in Simscape,” release 1.6.1, 2023. MATLAB Central File Exchange 92820. https://www.mathworks.com/matlabcentral/fileexchange/92820-hybrid-electric-vehicle-model-in-simscape ; release: https://github.com/mathworks/Simscape-Hybrid-Electric-Vehicle-Model/releases/tag/v1.6.1 .

[2] J. Xue and X. Jiao, “Speed cascade adaptive control for hybrid electric vehicle using electronic throttle control during car-following process,” ISA Transactions, vol. 110, pp. 328–343, 2021. https://doi.org/10.1016/j.isatra.2020.10.058 .

[3] J. Zhang, Q. Fan, M. Wang, B. Zhang and Y. Chen, “Robust speed tracking control for future electric vehicles under network-induced delay and road slope variation,” Sensors, vol. 22, no. 5, art. 1787, 2022. https://doi.org/10.3390/s22051787 .

[4] X. Li and Z. Xu, “Pattern-moving-based partial form dynamic linearization model free adaptive control for a class of nonlinear systems,” Actuators, vol. 10, no. 9, art. 223, 2021. https://doi.org/10.3390/act10090223 .

[5] C. Zhang, C. Cen and J. Huang, “An overview of model-free adaptive control for the wheeled mobile robot,” World Electric Vehicle Journal, vol. 15, no. 9, art. 396, 2024. https://doi.org/10.3390/wevj15090396 .

[6] Z. Xu, Y. Yin, H. Cai, W. Zhu, C. Dai and A. G. Gershome, “Hybrid model-based and data-driven sliding mode control for robust path tracking in intelligent vehicles,” IEEE Access, vol. 13, pp. 159920–159932, 2025. https://doi.org/10.1109/ACCESS.2025.3606861 .

[7] J. Li, Y. Wang, X. Zhao and P. Qi, “Model free adaptive control of large and flexible wind turbine rotors with controllable flaps,” Renewable Energy, vol. 180, pp. 68–82, 2021. https://doi.org/10.1016/j.renene.2021.08.050 .

[8] J. Abiola, O. Ajewole and P. Adewuyi, “Analysis of nonlinear control strategies for quadrotor stability and trajectory tracking,” ABUAD Journal of Engineering Research and Development, vol. 8, no. 2, pp. 185–208, 2025. https://doi.org/10.53982/ajerd.2025.0802.19-j .

[9] J. Abiola, H. S. Phuluwa, D. Aborisade, M. Okelola, G. Igbinigie and I. Daniyan, “Artificial intelligence-optimized hybrid hydrogen–battery energy storage for renewable microgrids,” Advanced Engineering Letters, vol. 5, no. 2, pp. 59–74, 2026. https://doi.org/10.46793/adeletters.2026.5.2.1 .

[10] X. Liu, H. Guo, X. Cheng, J. Du and J. Ma, “A robust design of the model-free-adaptive-control-based energy management for plug-in hybrid electric vehicle,” Energies, vol. 15, no. 20, art. 7467, 2022. https://doi.org/10.3390/en15207467 .

[11] M. Heydari, A. B. Novinzadeh and M. Tayefi, “Anti wind-up and robust data-driven model-free adaptive control for MIMO nonlinear discrete-time systems,” International Journal of Adaptive Control and Signal Processing, vol. 39, no. 10, pp. 2143–2157, 2025. https://doi.org/10.1002/acs.3907 .

[12] MathWorks, “mixsyn—Mixed-sensitivity H∞ synthesis method for robust control loop-shaping design,” Robust Control Toolbox documentation, MATLAB R2023a, 2023. https://www.mathworks.com/help/releases/R2023a/robust/ref/dynamicsystem.mixsyn.html .
